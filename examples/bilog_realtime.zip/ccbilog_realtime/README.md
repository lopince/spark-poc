StructStreaming清洗日志etl示例（读kafka -》 写hdfs）

