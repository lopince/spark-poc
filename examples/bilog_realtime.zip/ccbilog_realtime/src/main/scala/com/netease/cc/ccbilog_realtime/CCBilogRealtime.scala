package com.netease.cc.ccbilog_realtime

import java.io.{ObjectInputStream, ObjectOutputStream}
import java.text.SimpleDateFormat
import java.util.{Date, Properties}

import org.apache.spark.broadcast.Broadcast
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.streaming.ProcessingTime


/**
  */
object CCBilogRealtime {
  def main(args: Array[String]): Unit = {
    var mode: String = "prod"

    if (args.length > 0) {
      mode = args(0)
    }

    println(s"Running in $mode mode")

    val props = Config.getProperties(mode)
    val appName = CCBilogRealtime.getClass.getName.stripSuffix("$")
    val spark: SparkSession =
      SparkSession
        .builder
        //.enableHiveSupport()
        .appName(appName)
        .config("spark.streaming.stopGracefullyOnShutdown", "true")
        .config("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
        .config("spark.kryo.registrator", classOf[CCRegistrator].getName)
        .getOrCreate()

    // https://www.cnblogs.com/yy3b2007com/p/10610845.html
    DBUtils.setup(props)
    val bcClientTypeMap = BroadcastWrapper(spark, props)
    val statsdClient = StatsdClient(
      props.getProperty("statsd.prefix") + "." + appName.split("\\.").last,
      props.getProperty("statsd.host"),
      props.getProperty("statsd.port").toInt
    ).get_client()
    spark.streams.addListener(sparkstructurestreamingmonitor(spark, props, bcClientTypeMap, statsdClient))

    import spark.implicits._
    val logs = spark.readStream
      .format("kafka")
      .option("kafka.bootstrap.servers", props.getProperty("kafka.broker.list"))
      .option("subscribe", props.getProperty("kafka.topics"))
      .option("startingOffsets", props.getProperty("kafka.offset"))
      .load()
      .selectExpr("CAST(key AS STRING)", "CAST(value AS STRING)")
      .as[(String, String)]

    val logSteam = logs.map(log => transformLog(log._2, bcClientTypeMap.value))

    val logcc = logSteam.writeStream
      .outputMode("append")
      .trigger(ProcessingTime(props.getProperty("spark.batch_interval")))
      .format("text")
      .option("path", "/warehouse/cc/base/cc_bi_log_realtime")
      //  .option("orc.compress", "snappy")
      .partitionBy("logtype", "dt")
      .option("checkpointLocation", props.getProperty("spark.checkpoint"))
      .start()

    var stopped = false
    var batchId = 0L
    var newRows = 0L
    while (!stopped) {
      stopped = logcc.awaitTermination(10 * 1000)

      if (logcc.lastProgress != null) {
        val newBatchId = logcc.lastProgress.batchId
        if (batchId != newBatchId) {
          batchId = newBatchId
          newRows = logcc.lastProgress.numInputRows
        }
        else {
          newRows = 0L
        }
      }
      statsdClient.gauge("batch_id", batchId)
      statsdClient.count("num_input_rows", newRows)
    }
    println("stopped")
  }

  private def formatDate(line: String): (String, Long) = {
    var datestr = "error"
    var dateFf = 0L
    try {
      val date = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
      val dateFormatted = date.parse(line)
      val dateStrFormat = new SimpleDateFormat("yyyyMMdd")
      datestr = dateStrFormat.format(dateFormatted)
      dateFf = dateFormatted.getTime
    } catch {
      case e: Exception => e.printStackTrace()
    }
    (datestr, dateFf)
  }

  private def transformLog(log: String, clientTypeMap: Map[Int, ClientInfo]): CCBiSchema = {
    val currTime = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").format(new Date())
    val log_trim: String = log.trim()
    var logcontent = log_trim
    var logtype = "errorlogtype"
    var logtime = currTime

    try {
      // [2013-04-11 00:00:00][OnlineRoleNum],{"online":1000,"server":"1001","time":"2013041100"}
      val logtype_lastindex = log_trim.indexOf("],")
      val logtype_index = log_trim.lastIndexOf("][", logtype_lastindex)
      if (logtype_lastindex >= 0 && logtype_index >= 0) {
        logcontent = log_trim.substring(logtype_lastindex + 2)
        logtype = log_trim.substring(logtype_index + 2, logtype_lastindex)
        val logtime_index = log_trim.lastIndexOf('[', logtype_index)
        logtime = log_trim.substring(logtime_index + 1, logtype_index)

        try {
          logcontent = parseLogContent(logcontent, clientTypeMap)
        } catch {
          case e: Exception =>
            // 尝试替换掉所有非法的NaN, +-Infinity为-2
            val clean = logcontent.replaceAll("(^|\\[|\" *:|,)( *)(NaN|[+-]?Infinity)", "$1$2-2")
            if (clean != logcontent) {
              logcontent = parseLogContent(clean, clientTypeMap)
              println(s"Replace invalid NaN, Infinity to -2: logtype=$logtype logtime=$logtime error=${e.getMessage()}")
            }
            else {
              throw e
            }
        }
      }
    } catch {
      case e: Exception => println(s"Transform log failed: $e")
        logcontent = log_trim
        logtype = "errorlogtype"
        logtime = currTime
    }

    CCBiSchema(formatDate(logtime)._1, logtype, logcontent)
  }

  private def parseLogContent(logContent: String, clientTypeMap: Map[Int, ClientInfo]): String = {
    import net.liftweb.json._
    implicit val formats = DefaultFormats
    var jsonObj = parse(logContent)

    // Fix account_id in CC-Android <= 2.6.9
    var account_id = jsonObj.\("account_id").extractOrElse[String]("")
    if (account_id.endsWith("@android.cc.163.com")) {
      account_id = account_id.replace("@android.cc.163.com", "@ad.cc.163.com")
      jsonObj = jsonObj.merge(JObject(JField("account_id", JString(account_id))))
    }

    // Fix platform & os_name
    val clientType = jsonObj.\("client_type").extractOrElse[Int](-2)
    if (clientType != -2) {
      val info = clientTypeMap.getOrElse(clientType, null)
      if (info != null) {
        val platform = jsonObj.\("platform").extractOrElse[String]("")
        val osName = jsonObj.\("os_name").extractOrElse[String]("")
        if (info.platform != platform) {
          jsonObj = jsonObj.merge(JObject(JField("platform", JString(info.platform))))
        }
        if (info.os_name != osName) {
          jsonObj = jsonObj.merge(JObject(JField("os_name", JString(info.os_name))))
        }
      }
    }
    compactRender(jsonObj)
  }

  case class CCBiSchema(dt: String, logtype: String, json_args: String)
  case class ClientInfo(platform: String, os_name: String)

  // See https://www.cnblogs.com/xlturing/p/6652945.html
  // https://blog.csdn.net/dengxing1234/article/details/74330768
  case class BroadcastWrapper(
                               @transient private val ss: SparkSession,
                               @transient private val props: Properties) {

    @transient private var v: Broadcast[Map[Int, ClientInfo]] = ss.sparkContext.broadcast(loadClientTypeMap())

    def loadClientTypeMap(): Map[Int, ClientInfo] = {
      // https://stackoverflow.com/questions/19528104/how-to-create-a-connection-between-scala-and-mysql-using-jdbc
      val list = DBUtils.list("SELECT client_type, platform, os_name FROM cfg_client_type")
      val map = list.map(obj => (obj("client_type").asInstanceOf[Int], ClientInfo(obj("platform").asInstanceOf[String], obj("os_name").asInstanceOf[String]))).toMap
      map
    }

    def update(blocking: Boolean = false): Unit = {
      try {
        val map = loadClientTypeMap()
        v.unpersist(blocking)
        v = ss.sparkContext.broadcast(map)
      } catch {
        case e: Exception => e.printStackTrace()
      }
    }

    def value: Map[Int, ClientInfo] = v.value

    private def writeObject(out: ObjectOutputStream): Unit = {
      out.writeObject(v)
    }

    private def readObject(in: ObjectInputStream): Unit = {
      v = in.readObject().asInstanceOf[Broadcast[Map[Int, ClientInfo]]]
    }
  }

}
