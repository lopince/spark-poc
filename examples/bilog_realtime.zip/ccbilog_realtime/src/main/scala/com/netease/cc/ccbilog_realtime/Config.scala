package com.netease.cc.ccbilog_realtime

import java.util.Properties

/**
  */
object Config {

  def getProperties(mode: String): Properties = {
    if (mode.equals("prod")) {
      getProdProperties()
    }
    else if (mode.equals("local")) {
      getLocalProperties()
    }
    else {
      getDevProperties()
    }
  }

  private def getProdProperties(): Properties = {
    val properties = new Properties()
props.put("kafka.broker.list
props.put("kafka.topics"
props.put("hdfs.addr"
props.put("kafka.offset"
props.put("spark.batch_interval"
props.put("spark.checkpoint"
props.put("statsd.prefix"
props.put("statsd.host"
props.put("statsd.port"
props.put("log.level"
props.put("mysql.url"
props.put("mysql.user"
props.put("mysql.password"
props.put("reload_clienttype_interval_ms",
    properties
  }

  private def getDevProperties(): Properties = {
    val properties = new Properties()
props.put("kafka.broker.list
props.put("kafka.topics"
props.put("hdfs.addr"
props.put("kafka.offset"
props.put("spark.batch_interval"
props.put("spark.checkpoint"
props.put("statsd.prefix"
props.put("statsd.host"
props.put("statsd.port"
props.put("log.level"
props.put("mysql.url"
props.put("mysql.user"
props.put("mysql.password"
props.put("reload_clienttype_interval_ms",
    properties
  }

  private def getLocalProperties(): Properties = {
    val props = new Properties()
props.put("kafka.broker.list
props.put("kafka.topics"
props.put("hdfs.addr"
props.put("kafka.offset"
props.put("spark.batch_interval"
props.put("spark.checkpoint"
props.put("statsd.prefix"
props.put("statsd.host"
props.put("statsd.port"
props.put("log.level"
props.put("mysql.url"
props.put("mysql.user"
props.put("mysql.password"
props.put("reload_clienttype_interval_ms",
    props
  }
}
