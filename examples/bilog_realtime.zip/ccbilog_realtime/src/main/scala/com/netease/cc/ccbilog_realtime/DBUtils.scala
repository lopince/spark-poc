package com.netease.cc.ccbilog_realtime

import java.sql._
import java.util.Properties

import org.apache.commons.dbcp2._
import org.apache.commons.pool2.impl.{GenericObjectPool, GenericObjectPoolConfig}

import scala.collection.immutable
import scala.collection.mutable.ListBuffer

// See https://www.jianshu.com/p/afd993e610ff
object DBUtils {
  // 驱动程序类
  private var DB_DRIVER = "com.mysql.jdbc.Driver"
  // 数据库连接字符串
  private var DB_URL = ""
  // 数据库账户名
  private var DB_USER = ""
  // 数据库密码
  private var DB_PWD = ""
  private var isSetup = false
  private val POOL_URL = "jdbc:apache:commons:dbcp:"
  private val POOL_NAME = "my_pool"
  private val POOL_DRIVER = "org.apache.commons.dbcp2.PoolingDriver"

  def setup(props: Properties): Unit = {
    DB_DRIVER = props.getProperty("mysql.driver", DB_DRIVER)
    DB_URL = props.getProperty("mysql.url")
    DB_USER = props.getProperty("mysql.user")
    DB_PWD = props.getProperty("mysql.password")

    Class.forName(DB_DRIVER)
    setupDbcpDriver()

    isSetup = true
  }

  /**
    * See https://git-wip-us.apache.org/repos/asf?p=commons-dbcp.git;a=blob;f=doc/PoolingDriverExample.java;h=8fd8ec50ac14f66dec84342e7a441388932190d1;hb=HEAD
    */
  private def setupDbcpDriver(): Unit = {
    val connFactory = new DriverManagerConnectionFactory(DB_URL, DB_USER, DB_PWD)
    val poolableConnFactory = new PoolableConnectionFactory(connFactory, null)
    val poolConfig = new GenericObjectPoolConfig[PoolableConnection]()
    poolConfig.setMinIdle(1)
    poolConfig.setMaxWaitMillis(60 * 1000L)
    poolConfig.setMinEvictableIdleTimeMillis(60 * 60 * 1000L)
    val connPool = new GenericObjectPool[PoolableConnection](poolableConnFactory, poolConfig)
    poolableConnFactory.setPool(connPool)

    Class.forName(POOL_DRIVER)

    val driver = DriverManager.getDriver(POOL_URL).asInstanceOf[PoolingDriver]
    driver.registerPool(POOL_NAME, connPool)
    // Now we can just use the connect string "jdbc:apache:commons:dbcp:<POOL_NAME>"
    // to access our pool of Connections.
    val initialSize = 1
    for (_ <- 0 until initialSize) {
      connPool.addObject()
    }
  }

  def shutdown(): Unit = {
    val driver = DriverManager.getDriver(POOL_URL).asInstanceOf[PoolingDriver]
    driver.closePool(POOL_NAME)
  }

  /**
    * 获取数据库连接
    *
    * @return Connection据库连接
    */
  def getConn: Connection = {
    if (!isSetup) {
      throw new RuntimeException("Require call setup() first")
    }
    // DriverManager.getConnection(DB_URL, DB_USER, DB_PWD)
    DriverManager.getConnection(POOL_URL + POOL_NAME)
  }

  /**
    * 执行查询操作
    *
    * @param sql
    * 查询SQL语句
    * @param args
    * SQL语句 参数
    * @return 返回查询结果
    */
  def query(sql: String, args: Any*): Map[String, Any] = {
    var conn: Connection = null
    var pst: PreparedStatement = null
    var rs: ResultSet = null
    try {
      conn = getConn
      pst = conn.prepareStatement(sql)
      // 设置参数
      for (i <- 0 until args.length) {
        if (args(i) != null) pst.setObject(i + 1, args(i))
      }
      // 执行查询语句
      rs = pst.executeQuery
      if (rs.next) rsToMap(rs)
      else null
    } finally close(conn, pst, rs)
  }

  def list(sql: String, args: Any*): List[Map[String, Any]] = {
    var conn: Connection = null
    var pst: PreparedStatement = null
    var rs: ResultSet = null
    try {
      conn = getConn
      pst = conn.prepareStatement(sql)
      for (i <- 0 until args.length) {
        if (args(i) != null) pst.setObject(i + 1, args(i))
      }
      rs = pst.executeQuery
      val list = new ListBuffer[Map[String, Any]]()
      while (rs.next) {
        list += rsToMap(rs)
      }
      list.toList
    } finally close(conn, pst, rs)
  }

  /**
    * 执行增删改操作
    *
    * @param sql
    * 增删改SQL语句
    * @param args
    * SQL语句 参数
    * @return 返回是否执行成功
    */
  def update(sql: String, args: Any*): Boolean = {
    var conn: Connection = null
    var pst: PreparedStatement = null
    try {
      conn = getConn // 获取数据库连接
      pst = conn.prepareStatement(sql)
      for (i <- 0 until args.length)  {
        if (args(i) != null) pst.setObject(i + 1, args(i))
      }
      val row = pst.executeUpdate
      row > 0
    } finally close(conn, pst, null)
  }

  /**
    * 关闭连接释放资源
    *
    * @param conn
    * 数据库连接
    * @param st
    * Statement对象
    * @param rs
    * ResultSet 结果集
    */
  def close(conn: Connection, st: PreparedStatement, rs: ResultSet): Unit = {
    try {
      if (rs != null) rs.close()
      if (st != null) st.close()
      if (conn != null) conn.close()
    } catch {
      case e: SQLException =>
        e.printStackTrace()
    }
  }

  /**
    * 将结果集转换成Map
    *
    * @param rs
    * 结果集
    * @return map
    * @throws SQLException 数据库异常
    */
  @throws[SQLException]
  def rsToMap(rs: ResultSet): Map[String, Any] = {
    // 获取结果集的元信息(列名，列类型，大小，列数量等等)
    val rsmd = rs.getMetaData
    val count = rsmd.getColumnCount
    var map = immutable.Map.newBuilder[String, Any]
    // 获取结果集中的列的数量
    for (i <- 1 to count) {
      // 根据列的下标获取列名称
      val columnName = rsmd.getColumnName(i)
      val value = rs.getObject(i)
      map += (columnName.toLowerCase -> value)
    }
    map.result()
  }
}
