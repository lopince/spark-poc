package com.netease.cc.ccbilog_realtime

import com.esotericsoftware.kryo.Kryo
import com.esotericsoftware.kryo.io.{Input, Output}
import org.apache.spark.serializer.KryoRegistrator
import com.timgroup.statsd.NonBlockingStatsDClient

/**
  * Created by g8041 on 2018/4/12.
  */
object StatsdClient {
  def apply(prefix: String, host: String, port: Int): StatsdClient = {
    new StatsdClient(prefix, host, port)
  }
}

class StatsdClient(prefix: String, host: String, port: Int) {
  var statsd_prefix: String = prefix
  var statsd_host: String = host
  var statsd_port: Int = port
  var statsd_client = new NonBlockingStatsDClient(prefix, host, port)

  def get_client(): NonBlockingStatsDClient = {
    statsd_client
  }

  // sys.addShutdownHook(){
  //   statsd_client.stop()
  // }
}

class CCSerializer extends com.esotericsoftware.kryo.Serializer[StatsdClient] {
  override def write(kryo: Kryo, output: Output, statsd_client: StatsdClient): Unit = {
    output.writeString(statsd_client.statsd_prefix)
    output.writeString(statsd_client.statsd_host)
    output.writeInt(statsd_client.statsd_port)
  }

  override def read(kryo: Kryo, input: Input, t: Class[StatsdClient]): StatsdClient = {
    val prefix = input.readString()
    val host = input.readString()
    val port = input.readInt()
    new StatsdClient(prefix, host, port)
  }
}

class CCRegistrator extends KryoRegistrator {
  override def registerClasses(kryo: Kryo) {
    kryo.register(classOf[StatsdClient], new CCSerializer())
  }
}


