package com.netease.cc.ccbilog_realtime

import java.util.Properties

import com.netease.cc.ccbilog_realtime.CCBilogRealtime.BroadcastWrapper
import com.timgroup.statsd.NonBlockingStatsDClient
import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.streaming.StreamingQueryListener
import org.apache.spark.sql.streaming.StreamingQueryListener.{QueryProgressEvent, QueryStartedEvent, QueryTerminatedEvent}

/**
  */
object sparkstructurestreamingmonitor {
  def apply(ssc: SparkSession, props: Properties, bcClientTypeMap: BroadcastWrapper, statsdClient: NonBlockingStatsDClient): sparkstructurestreamingmonitor = {
    new sparkstructurestreamingmonitor(ssc, props, bcClientTypeMap, statsdClient)
  }
}


class sparkstructurestreamingmonitor(ssc: SparkSession, props: Properties, bcClientTypeMap: BroadcastWrapper, statsdClient: NonBlockingStatsDClient) extends StreamingQueryListener {
  /** Called when the streaming has been started */
  private val conf: SparkConf = ssc.sparkContext.getConf
  private var lastUpdateTime = 0L

  override def onQueryStarted(queryStarted: QueryStartedEvent): Unit = {
    println("Query started: " + queryStarted.id)
    statsdClient.increment(s"querystart")
  }

  override def onQueryTerminated(queryTerminated: QueryTerminatedEvent): Unit = {
    println("Query terminated: " + queryTerminated.id)
    statsdClient.increment(s"queryend")
  }

  override def onQueryProgress(queryProgress: QueryProgressEvent): Unit = {
    println("Query made progress: " + queryProgress.progress)
    statsdClient.increment(s"queryprogress")
    val interval = props.getProperty("reload_clienttype_interval_ms").toLong
    if (System.currentTimeMillis - lastUpdateTime > interval) {
      bcClientTypeMap.update(true)
      lastUpdateTime = System.currentTimeMillis
      println(s"Reload client type: ${bcClientTypeMap.value.size}")
    }
  }
}
